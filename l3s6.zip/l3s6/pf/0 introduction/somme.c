int somme(int n) {
    int i, somme;

    somme = 0;
    for (i = 0; i < n; i++) {
        somme += i;
    }

    return somme;
}
