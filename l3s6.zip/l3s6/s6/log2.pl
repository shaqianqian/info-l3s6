% test
grille([[_,_,_,_,_,_,_,_,_],
        [_,_,_,_,_,3,_,8,5],
        [_,_,1,_,2,_,_,_,_],
        [_,_,_,5,_,7,_,_,_],
        [_,_,4,_,_,_,1,_,_],
        [_,9,_,_,_,_,_,_,_],
        [5,_,_,_,_,_,_,7,3],
        [_,_,2,_,1,_,_,_,_],
        [_,_,_,_,4,_,_,_,9]]).

% q1
printline([]) :- writeln('|'), !.
printline([X|XS]) :- integer(X), !, write('|'), write(X), printline(XS).
printline([_|XS]):- write('|'), write(' '), printline(XS).


% q2

print([]).
print([L | G]) :- printline(L),print(G).


% q3

bonnelongueur([],0) .
bonnelongueur([_|XS],N):- bonnelongueur(XS,N1),N is (N1+1).

% q4
bonnetaille([],0).
bonnetaille([L|[]],N) :- bonnelongueur(L,N) .
bonnetaille([L|G],N) :- bonnelongueur(L,N),bonnetaille(G,N).


% test
verifier([]).
verifier(X) :- X ins 1..9.

% q5
:- use_module(library(clpfd)).
verifie([]).

verifie([L|G]) :- verifier(L),all_distinct(L),verifie(G).

% q6
eclate([],_,[]).
eclate([X|XS],[Y|YS],[[X|Y]|L2]) :- eclate(XS,YS,L2).

% q7
transp([],[]):-!.
transp([[X|XS]],[[X]|L]) :- transp([XS],L),!.
transp([X|XS],L) :- transp(XS, L2),eclate(X,L2,L).


% q8
decoupe([],[],[],[]).
decoupe([X,Y,Z | L1],[X1,Y1,Z1 |L2],[X2,Y2,Z2 |L3],[[X,Y,Z,X1,Y1,Z1,X2,Y2,Z2] | C]) :- decoupe(L1,L2,L3,C).

% q9
carres([],[]).
carres([X,Y,Z|XS],L) :- decoupe(X,Y,Z,L1), carres(XS,L2),append(L1,L2,L).


% q10
solution(S):- transp(S,TS), carres(S,CS), bonnetaille(S,9),verifie(CS),bonnetaille(TS,9), verifie(S),verifie(TS).
