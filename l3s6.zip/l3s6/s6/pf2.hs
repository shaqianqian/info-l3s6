import Graphics.Gloss

main = animate (InWindow "Dragon" (500, 500) (0, 0))
white (dragonAnime (50,250) (450,250))
dragonAnime a b t = Line (dragon a b !! (round t `mod` 20))



--e1
alterne :: [a]->[a]
alterne []=[]
alterne [x]=[x]
alterne (x:y:xs)=x : alterne (xs)


--e2

combine :: (a -> b -> c) -> [a] -> [b] -> [c]
combine f [] y = []
combine f x [] = []
combine f (x:xs) (y:ys) = [f x y] ++ (combine f xs ys)


--e3

pasPascal ::[Int] -> [Int]
pasPascal []=[]
pasPascal xs=zipWith (+) (0:xs) (xs ++ [0])


--e4

pascal :: [[Int]]
pascal  = iterate pasPascal [1]

--e5



type Point = (Float, Float)
type Path  = [Point]

pointAintercaler :: Point -> Point -> Point
pointAintercaler (xA,yA) (xB,yB) = ((xA + xB)/2 + (yB - yA)/2, (yA + yB)/2 + (xA - xB)/2)
